﻿from ultralytics import YOLO

model = YOLO(r"apple_mini.pt")

model.predict(
    source=r"D:\DeepLearning\ultralytics-8.3.163\datasets\test_dataset\images\val",
    save=True,
    show=False,
    conf=0.01,
)